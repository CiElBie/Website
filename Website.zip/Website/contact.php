<!DOCTYPE html>

<html lang="en">
  <head>  
    <!--meta data-->
    <meta charset="utf-8">
    <title>Contact</title>
    <link rel="stylesheet" href="CSS.css">
    <!--<script src="Javascript.js"></script>-->
  </head>
  <body>

    <a class="header" href="http://localhost:3000/about.html" ></a>

    <nav>
         <a class="centernav" href="http://localhost:3000/about.html" >About</a>
         <a class="centernav" href="http://localhost:3000/trampolines.html" >Trampolines</a>
         <a class="centernav" href="http://localhost:3000/crutches.html" >Crutches</a>
         <a class="centernav" href="http://localhost:3000/contact.php" >Contact Us</a>
    </nav>
    
    <main>
      <h1>Contact Us:</h1>

      
      <?php 


      $name = "";
      $email = "";  
      $message = "";  
      $product = "";
      $nameErr = "";
      $messageErr = "";
      $emailErr = "";
      $error = false;
      $sent = false;


      
      
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (empty($_POST["name"])) {
          $nameErr = "ERROR: Name is required";
          $error = true;
        } else {
          $name = test_input($_POST["name"]);
          // check if name only contains letters and whitespace
          if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
            $nameErr = "ERROR: Only letters and white space allowed";
            $error = true;
          }
        }
      }
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (empty($_POST["email"])) {
          $emailErr = "ERROR:  Email is required";
          $error = true;
        } else {
          $email = test_input($_POST["email"]);
          $sent = true;

          
        }
      }
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (empty($_POST["message"])) {
          $messageErr = "ERROR:  A message is required";
          $error = true;
        } else {
          $message = test_input($_POST["message"]);
          // check if name only contains letters and whitespace

          
        }
      }

      if ($_SERVER["REQUEST_METHOD"] == "POST") {
          $product = $_POST['product'];
        }
      


      
      function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
       return $data;
      }


      ?>
         
       <form action="contact.php" method="post">

        <label font COLOR="red"><?php if ($error == false && $sent == true){echo '<span style="color:Red;text-align:center;">Thank you!  Your message was sent successfully.<br><br></span>';}?>
        
        <label for="name">Name:<font COLOR="red">*  <?php echo $nameErr; ?></font></label><br>
        <input type="text" id="name" name="name" size="30" value= "<?php if ($error == true){echo $name;}?>"><br>
        <label for="email">Email:<font COLOR="red">*  <?php echo $emailErr; ?></font></label><br>
        <input type="text" id="email" name="email" size="30" value= "<?php if ($error == true){echo $email;}?>"></input><br>
        <br>

        <label for="product">What product are you inquiring about:</label><br>
        <input type="radio" id="Trampolines" name="product" value="Trampolines" <?php if($error == true){if($_POST['product']=="Trampolines"){echo 'checked';}} ?>> 
        <label for="tramp">Trampolines  </label>
        <input type="radio" id="Crutches" name="product" value="Crutches" <?php if($error == true){if($_POST['product']=="Crutches"){echo 'checked';}}?> >
        <label for="crutch">Crutches  </label>
        <input type="radio" id="General" name="product" value="General" <?php if($error == true){if($_POST['product']=="General"){echo 'checked';}}?>>
        <label for="javascript">General Inquiry</label><br>
        <br>

        <label for="message">Message:<font COLOR="red">* <?php echo $messageErr; ?></font></label><br>
        <textarea id="message" name="message" rows="4" cols="50" placeholder="Write your message here"><?php if ($error == true){echo $message;} ?></textarea><br>
        <br>
        
        <input type="submit" value="Submit">
      </form>

      <?php 
        if ($sent == true && $error == false){
        echo "<br>";
        echo "<br>";
        echo $name;
        echo "<br>" ;
        echo $email; 
        echo "<br>" ;
        echo $product;
        echo "<br>" ;
        echo $message; 
        echo "<br>" ;

      }?>

    </main>

    <footer>
     <a class="email" href="bouncewright@bounce.co.uk">bouncewright@bounce.co.uk</a>
     <p>* Wright's Trampolines & Crutches are not to be held responsible for anything that happens while using our products</p>
    </footer>
  </body>
</html>  